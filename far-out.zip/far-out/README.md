# Far Out 🪐

A group rare-answer party game. Everyone in a room gets the same 7 prompts, 25 seconds each.
Any correct answer counts, but the rarer it is, the farther you fly:

| Tier | Points |
|---|---|
| Launchpad (what everyone says) | 10 |
| Low Orbit | 30 |
| Deep Space | 60 |
| Far Out | 100 |
| 🛰️ Solo flight — nobody else in the room said it | +20 |

## Deploy to Netlify

The game needs a small server function (rooms and scores are stored with Netlify Blobs),
so **drag-and-drop "Netlify Drop" won't work** — use one of these:

**Option A — GitHub (easiest to update later)**
1. Put this folder in a new GitHub repo.
2. Netlify → *Add new site* → *Import an existing project* → pick the repo.
3. Leave the settings as they are (they come from `netlify.toml`) and click *Deploy*.

**Option B — Netlify CLI**
```
npm install
npx netlify-cli deploy --prod
```

Netlify Blobs turns on automatically — no database or keys to set up.

## Playing
1. Open the site, type your name, tap **Create a room**.
2. Tap **Share invite link** and send it to your sisters (or tell them the 4-letter code).
3. When everyone's in, the host taps **Start**. Scores appear once everyone finishes.
4. The host taps **Next round** for 7 new prompts (no repeats for the first 3 rounds).

## Adding your own prompts
Open `public/bank.js` and add an entry — four tiers of answers, separated by `|`:
```js
{ q: "Name a Dubai mall", t: ["dubai mall|mall of the emirates", "ibn battuta|city centre deira", "...", "..."] },
```
