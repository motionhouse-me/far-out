// Far Out — prompt & answer bank.
// Each prompt has four tiers, from the answer everyone blurts out to the truly far-out:
//   [0] Launchpad (10)   [1] Low Orbit (30)   [2] Deep Space (60)   [3] Far Out (100)
// Add your own prompts at the bottom — answers separated by "|".
window.BANK = [
  { q: "Name a fruit", t: [
    "apple|banana|orange|strawberry|grape|mango|watermelon|pineapple",
    "pear|peach|cherry|kiwi|lemon|blueberry|raspberry|plum|pomegranate|melon|lime|coconut|apricot|papaya|grapefruit|fig|date",
    "lychee|guava|passion fruit|nectarine|cantaloupe|tangerine|clementine|mandarin|blackberry|cranberry|avocado|persimmon|honeydew|dragon fruit|kumquat|mulberry|gooseberry|quince",
    "durian|rambutan|mangosteen|jackfruit|soursop|starfruit|carambola|longan|loquat|feijoa|salak|cherimoya|tamarind|pawpaw|jabuticaba|ackee|lingonberry|elderberry|yuzu|pomelo|physalis|medlar|sapodilla|breadfruit|cloudberry"] },

  { q: "Name a country in Africa", t: [
    "egypt|south africa|nigeria|kenya|morocco",
    "ghana|ethiopia|algeria|tunisia|sudan|somalia|tanzania|uganda|libya|zimbabwe|senegal|cameroon",
    "angola|mali|madagascar|rwanda|namibia|botswana|zambia|ivory coast|cote d'ivoire|mozambique|congo|democratic republic of the congo|drc|niger|chad|mauritania|south sudan|eritrea|malawi",
    "lesotho|eswatini|swaziland|djibouti|gabon|benin|togo|burkina faso|burundi|guinea|guinea-bissau|equatorial guinea|sierra leone|liberia|gambia|cape verde|cabo verde|comoros|seychelles|mauritius|sao tome and principe|central african republic"] },

  { q: "Name a dog breed", t: [
    "labrador|golden retriever|german shepherd|poodle|bulldog|husky|chihuahua",
    "beagle|pug|dalmatian|rottweiler|corgi|shih tzu|pomeranian|dachshund|boxer|doberman|border collie|french bulldog|yorkshire terrier|yorkie|great dane|maltese",
    "shiba inu|akita|samoyed|saint bernard|bernese mountain dog|cocker spaniel|greyhound|whippet|chow chow|bichon frise|jack russell|pitbull|cavalier king charles spaniel|schnauzer|australian shepherd|malamute|alaskan malamute|newfoundland|basset hound|bloodhound|shar pei|weimaraner|vizsla",
    "saluki|basenji|borzoi|komondor|puli|xoloitzcuintli|xolo|affenpinscher|lagotto romagnolo|azawakh|otterhound|leonberger|briard|kuvasz|sloughi|keeshond|schipperke|bedlington terrier|norwegian lundehund|mudi|catahoula|tibetan mastiff|pharaoh hound|ibizan hound|dandie dinmont terrier"] },

  { q: "Name a planet or moon in our solar system", t: [
    "earth|mars|jupiter|saturn|moon",
    "venus|mercury|neptune|uranus|pluto",
    "titan|europa|io|ganymede|callisto|phobos|deimos|triton|enceladus|charon",
    "miranda|titania|oberon|umbriel|ariel|mimas|tethys|dione|rhea|iapetus|hyperion|phoebe|nereid|proteus|amalthea|ceres|eris|haumea|makemake|himalia|pan|janus|epimetheus|puck"] },

  { q: "Name a colour", t: [
    "red|blue|green|yellow|black|white|pink|purple|orange",
    "brown|grey|gray|gold|silver|navy|beige|turquoise|violet|maroon|teal",
    "lavender|magenta|cyan|indigo|crimson|lilac|mint|olive|peach|coral|burgundy|ivory|cream|khaki|scarlet|aqua|lime|tan|charcoal|mustard",
    "chartreuse|vermilion|vermillion|cerulean|ochre|periwinkle|mauve|fuchsia|taupe|puce|sienna|umber|celadon|aubergine|amaranth|cobalt|ultramarine|sepia|eggshell|cinnabar|zaffre|wisteria|gamboge|xanadu|saffron"] },

  { q: "Name a vegetable", t: [
    "carrot|potato|tomato|broccoli|onion|cucumber|lettuce",
    "spinach|cabbage|pepper|corn|peas|garlic|cauliflower|celery|eggplant|aubergine|zucchini|courgette|mushroom|pumpkin|bell pepper|bean|green beans",
    "kale|asparagus|beetroot|beet|radish|sweet potato|leek|artichoke|okra|brussels sprouts|turnip|squash|parsnip|bok choy|chard",
    "kohlrabi|celeriac|fennel|rutabaga|swede|jicama|salsify|romanesco|daikon|mooli|taro|cassava|yam|watercress|endive|chicory|radicchio|samphire|sunchoke|jerusalem artichoke|bitter melon|lotus root|fiddlehead|molokhia|purslane"] },

  { q: "Name a sport", t: [
    "football|soccer|basketball|tennis|swimming",
    "cricket|baseball|volleyball|golf|rugby|boxing|hockey|running|cycling|badminton|table tennis|ping pong",
    "handball|water polo|fencing|rowing|surfing|skiing|snowboarding|gymnastics|wrestling|karate|judo|taekwondo|archery|squash|netball|lacrosse|polo|sailing|bowling|darts|snooker|padel",
    "curling|sepak takraw|kabaddi|hurling|bobsleigh|luge|skeleton|biathlon|korfball|jai alai|pelota|underwater hockey|octopush|camel racing|falconry|bossaball|sumo|modern pentathlon|pentathlon|canoe polo|kendo|parkour|shinty|bandy|teqball"] },

  { q: "Name an animal that lives in the ocean", t: [
    "shark|whale|dolphin|fish|octopus|jellyfish",
    "crab|lobster|seal|turtle|sea turtle|starfish|squid|shrimp|stingray|clownfish|seahorse|tuna",
    "orca|manta ray|walrus|eel|moray eel|narwhal|sea lion|sea urchin|clam|oyster|mussel|barracuda|swordfish|pufferfish|beluga|cuttlefish|krill|coral|anemone|sea otter|plankton",
    "dugong|manatee|nudibranch|sea cucumber|anglerfish|blobfish|oarfish|sunfish|mola mola|lionfish|wobbegong|sea slug|hagfish|lamprey|vampire squid|nautilus|frogfish|goblin shark|isopod|barreleye|siphonophore|leafy sea dragon|sea pen|mantis shrimp|parrotfish"] },

  { q: "Name a capital city in Europe", t: [
    "paris|london|rome|madrid|berlin",
    "amsterdam|vienna|athens|lisbon|dublin|brussels|prague|moscow|stockholm|oslo|copenhagen",
    "warsaw|budapest|helsinki|bern|bucharest|sofia|belgrade|zagreb|kyiv|kiev|edinburgh|cardiff|reykjavik|monaco|luxembourg|bratislava",
    "vilnius|riga|tallinn|ljubljana|valletta|tirana|skopje|podgorica|sarajevo|chisinau|minsk|andorra la vella|vaduz|san marino|nicosia|vatican city|pristina|tbilisi|yerevan|baku|belfast"] },

  { q: "Name a musical instrument", t: [
    "piano|guitar|drums|violin|flute",
    "trumpet|saxophone|cello|harp|clarinet|keyboard|bass|ukulele|tambourine|recorder|xylophone",
    "oboe|trombone|tuba|banjo|accordion|harmonica|bagpipes|viola|french horn|double bass|bassoon|mandolin|triangle|organ|oud|sitar|bongos|maracas|synthesizer|cymbal",
    "theremin|didgeridoo|hurdy-gurdy|kalimba|glockenspiel|celesta|sousaphone|ocarina|qanun|kanun|darbuka|riq|ney|balalaika|koto|shamisen|erhu|tabla|marimba|vibraphone|harpsichord|dulcimer|zither|kazoo|bodhran|steelpan|steel drum|lute|piccolo|euphonium|cajon|handpan"] },

  { q: "Name a spice or herb", t: [
    "salt|pepper|cinnamon|basil|garlic|chili",
    "oregano|cumin|paprika|turmeric|ginger|mint|parsley|rosemary|thyme|coriander|cilantro|nutmeg|curry|saffron",
    "cardamom|clove|dill|sage|bay leaf|chives|fennel|tarragon|vanilla|star anise|anise|sumac|za'atar|zaatar|cayenne|mustard seed|allspice|chilli",
    "fenugreek|asafoetida|galangal|lemongrass|mahlab|nigella|black seed|marjoram|savory|lovage|sorrel|chervil|epazote|grains of paradise|long pepper|sichuan pepper|annatto|achiote|kaffir lime|makrut lime|juniper|mace|loomi|dried lime|baharat|ras el hanout|caraway|amchur|ajwain"] },

  { q: "Name a type of pasta", t: [
    "spaghetti|penne|macaroni|lasagna|fettuccine",
    "ravioli|linguine|tagliatelle|fusilli|rigatoni|farfalle|bowtie|tortellini|gnocchi|lasagne",
    "orzo|pappardelle|conchiglie|shells|cannelloni|angel hair|capellini|ziti|rotini|vermicelli|bucatini|tortelloni|gemelli|ditalini",
    "orecchiette|trofie|strozzapreti|casarecce|cavatappi|cavatelli|radiatori|campanelle|paccheri|mafaldine|bigoli|pici|garganelli|agnolotti|cappelletti|anelli|stelline|lumache|creste di gallo|fregola|malloreddus|corzetti|calamarata|lorighittas"] },

  { q: "Name a bird", t: [
    "eagle|parrot|penguin|pigeon|owl|chicken",
    "duck|swan|flamingo|crow|robin|sparrow|peacock|hawk|falcon|ostrich|seagull|gull|turkey|goose|hummingbird",
    "toucan|pelican|stork|heron|woodpecker|kingfisher|vulture|raven|magpie|canary|cockatoo|macaw|emu|kiwi|blue jay|cardinal|albatross|puffin|condor|budgie|parakeet|crane|quail",
    "shoebill|hoopoe|kakapo|cassowary|lyrebird|bee-eater|secretary bird|frigatebird|booby|blue-footed booby|ibis|spoonbill|nightjar|oriole|wren|warbler|bulbul|myna|mynah|hornbill|kookaburra|tern|plover|bittern|rhea|potoo|quetzal|treecreeper|nuthatch|houbara|sandgrouse"] },

  { q: "Name a gemstone", t: [
    "diamond|ruby|emerald|sapphire",
    "pearl|amethyst|opal|topaz|jade|onyx",
    "garnet|turquoise|aquamarine|peridot|citrine|tanzanite|lapis lazuli|lapis|moonstone|amber|quartz|rose quartz|tourmaline",
    "alexandrite|spinel|zircon|morganite|kunzite|iolite|chrysoberyl|tsavorite|malachite|obsidian|carnelian|beryl|jasper|agate|bloodstone|labradorite|sunstone|benitoite|painite|taaffeite|demantoid|rhodochrosite|sodalite|tiger's eye|chalcedony|larimar|hematite"] },

  { q: "Name a part of the body", t: [
    "hand|head|arm|leg|eye|nose|foot|mouth",
    "ear|finger|toe|knee|elbow|heart|brain|hair|shoulder|neck|stomach|back|chest|lip|tongue|teeth|tooth",
    "liver|lung|kidney|wrist|ankle|heel|thumb|eyebrow|eyelash|chin|cheek|forehead|hip|thigh|calf|spine|rib|skull|skin|nail|palm|jaw",
    "uvula|spleen|pancreas|appendix|gallbladder|philtrum|septum|clavicle|sternum|femur|tibia|fibula|patella|scapula|coccyx|cochlea|epiglottis|larynx|pharynx|diaphragm|thymus|thyroid|hypothalamus|cerebellum|duodenum|achilles tendon|earlobe|cuticle|nape|armpit|axilla"] },

  { q: "Name a cheese", t: [
    "cheddar|mozzarella|parmesan|feta",
    "brie|gouda|swiss|cream cheese|camembert|halloumi|blue cheese|goat cheese|ricotta|edam",
    "gorgonzola|roquefort|stilton|emmental|gruyere|mascarpone|provolone|manchego|paneer|cottage cheese|burrata|monterey jack|colby|pecorino|havarti|akkawi",
    "comte|raclette|taleggio|fontina|reblochon|epoisses|munster|limburger|jarlsberg|wensleydale|red leicester|double gloucester|labneh|nabulsi|queso fresco|cotija|oaxaca|asiago|caciocavallo|stracciatella|scamorza|tete de moine|mimolette|vacherin|casu marzu|kashkaval|shanklish|chhena|brunost"] },

  { q: "Name a country in Asia", t: [
    "china|japan|india|korea|south korea",
    "thailand|vietnam|indonesia|philippines|pakistan|malaysia|singapore|north korea|saudi arabia|uae|united arab emirates|bangladesh|nepal|sri lanka|iran|turkey",
    "mongolia|cambodia|laos|myanmar|burma|afghanistan|iraq|qatar|kuwait|oman|bahrain|jordan|lebanon|syria|israel|taiwan|kazakhstan|uzbekistan|maldives|yemen|bhutan",
    "brunei|timor-leste|east timor|kyrgyzstan|tajikistan|turkmenistan|georgia|armenia|azerbaijan|cyprus|palestine"] },

  { q: "Name a dessert", t: [
    "cake|ice cream|chocolate|cookie|brownie",
    "cheesecake|pie|donut|doughnut|cupcake|pudding|tiramisu|pancake|waffle|muffin|apple pie|macaron|crepe",
    "baklava|kunafa|knafeh|kunafeh|creme brulee|mousse|panna cotta|eclair|cinnamon roll|churros|gelato|sorbet|trifle|tart|pavlova|profiterole|flan|um ali|umm ali|luqaimat|basbousa|mochi",
    "rum baba|baba au rhum|clafoutis|tarte tatin|mille-feuille|cannoli|sfogliatella|zabaglione|semifreddo|affogato|kulfi|gulab jamun|jalebi|rasmalai|halva|halwa|malabi|muhallebi|sticky toffee pudding|eton mess|banoffee|bread pudding|cobbler|crumble|baked alaska|kouign-amann|dango|bingsu|halo-halo|pastel de nata|brigadeiro|tres leches|black forest|lamington"] },

  { q: "Name a chemical element", t: [
    "oxygen|hydrogen|gold|iron|carbon|silver",
    "helium|nitrogen|copper|calcium|sodium|aluminium|aluminum|zinc|lead|uranium|neon|mercury",
    "potassium|magnesium|chlorine|sulfur|sulphur|platinum|titanium|silicon|nickel|tin|lithium|phosphorus|plutonium|argon|cobalt|iodine|fluorine|chromium|tungsten|radium",
    "beryllium|boron|scandium|vanadium|manganese|gallium|germanium|arsenic|selenium|bromine|krypton|rubidium|strontium|yttrium|zirconium|niobium|molybdenum|technetium|ruthenium|rhodium|palladium|cadmium|indium|antimony|tellurium|xenon|caesium|cesium|barium|lanthanum|cerium|neodymium|europium|gadolinium|hafnium|tantalum|rhenium|osmium|iridium|thallium|bismuth|polonium|astatine|radon|francium|actinium|thorium|americium|einsteinium|oganesson|nobelium|curium|fermium|lutetium|ytterbium|erbium|holmium|dysprosium|terbium|samarium|promethium|praseodymium|thulium|protactinium|neptunium|berkelium|californium|mendelevium|lawrencium|rutherfordium|dubnium|seaborgium|bohrium|hassium|meitnerium|darmstadtium|roentgenium|copernicium|nihonium|flerovium|moscovium|livermorium|tennessine"] },

  { q: "Name something you'd find in a kitchen drawer", t: [
    "knife|spoon|fork|spatula",
    "whisk|ladle|tongs|peeler|grater|can opener|scissors|chopsticks|teaspoon|tablespoon",
    "zester|garlic press|measuring cup|measuring spoon|corkscrew|bottle opener|thermometer|pizza cutter|ice cream scoop|skewer|rolling pin|lighter|matches|rubber band|foil|cling film|baking paper|parchment paper|tea towel|batteries|takeaway menu",
    "mezzaluna|spider|melon baller|pastry brush|bench scraper|dough scraper|piping bag|ricer|potato masher|nutcracker|baster|spurtle|microplane|egg separator|lemon squeezer|reamer|cherry pitter|apple corer|mandoline|pastry cutter|cookie cutter|twist tie|bag clip|meat tenderizer|fish slice|zip tie|birthday candles|spare keys"] },

  { q: "Name a flower", t: [
    "rose|tulip|sunflower|daisy|lily",
    "orchid|lavender|jasmine|daffodil|lotus|carnation|poppy|dandelion|hibiscus|marigold|violet",
    "peony|chrysanthemum|iris|lilac|magnolia|cherry blossom|gardenia|camellia|hydrangea|bluebell|lily of the valley|forget-me-not|freesia|gerbera|begonia|zinnia|azalea|petunia|pansy|cosmos|bougainvillea|frangipani|plumeria|dahlia",
    "edelweiss|protea|bird of paradise|strelitzia|anemone|ranunculus|delphinium|foxglove|snapdragon|lisianthus|amaryllis|hellebore|wisteria|clematis|calla lily|anthurium|gladiolus|hyacinth|crocus|snowdrop|primrose|cornflower|amaranth|sweet pea|heather|aster|columbine|lupin|alstroemeria|corpse flower|rafflesia"] },

  { q: "Name a mammal", t: [
    "dog|cat|lion|elephant|tiger|horse|cow|human",
    "bear|monkey|giraffe|zebra|wolf|fox|rabbit|mouse|rat|pig|sheep|goat|deer|camel|kangaroo|whale|dolphin|bat|panda|squirrel|hippo|hippopotamus|rhino|rhinoceros",
    "cheetah|leopard|jaguar|gorilla|chimpanzee|orangutan|koala|sloth|otter|beaver|hedgehog|raccoon|skunk|moose|bison|buffalo|llama|alpaca|hyena|meerkat|lemur|badger|porcupine|seal|walrus|platypus|armadillo|anteater|oryx|gazelle|hamster|ferret|donkey|mole",
    "okapi|aardvark|pangolin|tapir|capybara|wombat|quokka|numbat|echidna|dugong|manatee|narwhal|binturong|fossa|aye-aye|tarsier|slow loris|loris|caracal|serval|ocelot|kinkajou|coati|dik-dik|saiga|markhor|ibex|gerenuk|bongo|kudu|wolverine|marten|mongoose|hyrax|shrew|vole|jerboa|chinchilla|degu|bandicoot|bilby|sugar glider|takin|addax|red panda"] },

  { q: "Name a style of dance", t: [
    "ballet|hip hop|salsa|tango|breakdance",
    "waltz|jazz|tap|contemporary|belly dance|ballroom|disco|samba|zumba|bollywood",
    "flamenco|cha cha|rumba|foxtrot|swing|street dance|line dance|irish dance|k-pop|kathak|bharatanatyam|dabke|krump|twerk|moonwalk|macarena|tutting|voguing|vogue|lambada",
    "quickstep|paso doble|lindy hop|charleston|bachata|kizomba|merengue|cumbia|polka|mazurka|jive|bolero|capoeira|haka|hula|morris dance|clogging|sirtaki|khaleegi|al ayyala|ayyala|tahtib|tanoura|sufi whirling|popping|locking|waacking|butoh|bhangra|odissi|kuchipudi|garba|riverdance|cancan|can-can"] },

  { q: "Name an item of clothing", t: [
    "shirt|t-shirt|pants|jeans|dress|jacket|shoes|socks",
    "skirt|sweater|hoodie|coat|hat|scarf|shorts|trousers|blouse|suit|tie|gloves|jumper|cardigan|pajamas|pyjamas|boots",
    "abaya|kandura|thobe|dishdasha|hijab|shayla|sari|saree|kimono|blazer|vest|waistcoat|leggings|tracksuit|overalls|dungarees|poncho|cape|beanie|sandals|slippers|sneakers|trainers|robe|bathrobe|swimsuit|bikini|tuxedo|jumpsuit|romper|turtleneck|polo",
    "kaftan|caftan|jalabiya|ghutra|keffiyeh|agal|bisht|niqab|kilt|sarong|lederhosen|dirndl|hanbok|cheongsam|qipao|ao dai|dashiki|kurta|salwar kameez|lehenga|sherwani|toga|tunic|corset|petticoat|culottes|jodhpurs|balaclava|beret|fedora|fez|sombrero|cravat|ascot|bolero|pashmina|galabeya|mukluk|espadrilles|clogs|loafers|brogues|moccasins"] },

  { q: "Name a job", t: [
    "doctor|teacher|nurse|engineer|lawyer|police officer|chef|firefighter",
    "pilot|dentist|accountant|architect|scientist|artist|actor|singer|farmer|mechanic|plumber|electrician|programmer|developer|designer|journalist|photographer|cashier|waiter|soldier|banker",
    "surgeon|pharmacist|vet|veterinarian|astronaut|judge|librarian|carpenter|baker|butcher|barber|hairdresser|psychologist|therapist|translator|interpreter|tailor|florist|paramedic|cameraman|editor|animator|economist|realtor|estate agent|flight attendant|lifeguard|zookeeper|detective|diplomat",
    "sommelier|cartographer|actuary|lexicographer|taxidermist|farrier|cooper|chandler|milliner|cobbler|glazier|luthier|horologist|perfumer|falconer|apiarist|beekeeper|archivist|curator|stenographer|ombudsman|toxicologist|seismologist|volcanologist|ornithologist|entomologist|cryptographer|sound engineer|foley artist|stunt double|stuntman|puppeteer|mortician|embalmer|chimney sweep|locksmith|blacksmith|stevedore|sherpa|town crier"] },

  { q: "Name a car brand", t: [
    "toyota|bmw|mercedes|ferrari|ford|nissan|tesla",
    "audi|honda|lamborghini|porsche|chevrolet|chevy|volkswagen|vw|hyundai|kia|lexus|jeep|land rover|range rover|mazda|bentley|rolls royce",
    "mitsubishi|subaru|volvo|jaguar|maserati|bugatti|mclaren|aston martin|peugeot|renault|fiat|dodge|cadillac|gmc|infiniti|genesis|mini|suzuki|lincoln|alfa romeo|citroen|skoda|byd|chrysler|buick|ram",
    "koenigsegg|pagani|lotus|seat|cupra|dacia|lancia|opel|vauxhall|saab|polestar|rivian|lucid|smart|tata|mahindra|proton|perodua|geely|chery|nio|xpeng|haval|lada|w motors|ssangyong|holden|pontiac|hummer|maybach|alpine|morgan|caterham|spyker|rimac|zenvo|devel"] },

  { q: "Name a Middle Eastern dish", t: [
    "hummus|shawarma|falafel|kebab|biryani",
    "tabbouleh|fattoush|kabsa|mandi|machboos|majboos|manakish|manoushe|baba ganoush|mutabal|shish tawook|tawook|kofta|labneh|samosa|harees",
    "mansaf|maqluba|maqlooba|musakhan|fatteh|kibbeh|warak enab|vine leaves|dolma|molokhia|mulukhiyah|koshari|kushari|ful|ful medames|shakshuka|freekeh|thareed|tharid|luqaimat|kunafa|knafeh|um ali|balaleet|chebab|regag|saloona|madrouba|jareesh",
    "muhammara|kubba|sfiha|fatayer|arayes|mujaddara|mjaddara|sayadieh|quzi|ouzi|makdous|shanklish|maamoul|qatayef|basbousa|halawet el jeben|aseeda|harira|tagine|pastilla|bastilla|couscous|mehshi|mahshi|batata harra|kibbeh nayeh|makloubeh|samboosa|khubz|lahm bi ajeen|shorbat adas|lentil soup|fesenjan|tahdig|ghormeh sabzi"] },

  { q: "Name an app on your phone", t: [
    "whatsapp|instagram|tiktok|youtube|snapchat",
    "facebook|twitter|x|spotify|netflix|google maps|gmail|chatgpt|telegram|uber|careem|talabat|amazon|pinterest|calculator|camera|photos|settings",
    "discord|reddit|linkedin|threads|zoom|teams|slack|duolingo|shazam|deliveroo|noon|canva|capcut|notion|waze|google translate|translate|calendar|clock|notes|weather|messages|safari|chrome|bereal|claude",
    "strava|goodreads|letterboxd|tumblr|signal|viber|wechat|kakaotalk|bumble|vinted|depop|shein|temu|instashop|entertainer|uae pass|dubai now|nol pay|tabby|tamara|google lens|authenticator|voice memos|compass|measure|magnifier|wallet|health|find my|podcasts|audible|kindle|wattpad|webtoon|roblox|minecraft|candy crush|wordle|lichess|headspace|calm|anghami|soundcloud|deezer|tidal|vsco|lightroom|procreate|picsart|snapseed"] },
];
